package com.example.iconcolorstudio;

import android.app.*;
import android.os.Bundle;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.content.Intent;
import android.net.Uri;
import android.view.Gravity;
import android.widget.*;
import java.io.*;
import java.util.*;
import java.util.zip.*;

public class MainActivity extends Activity {
    private final List<String> icons = new ArrayList<>();
    private int backgroundColor = Color.rgb(90,55,33);
    private int logoColor = Color.rgb(251,184,132);
    private GridLayout grid;
    private TextView bgLabel, logoLabel;
    private TextView previewStatus;
    private int dp(float v) { return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    private GradientDrawable shape(int color,int radius) {
        GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private TextView txt(String s,int size,int color) {
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); return t;
    }
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        try { String[] a=getAssets().list("icons"); if(a!=null) for(String n:a) if(n.toLowerCase(Locale.ROOT).endsWith(".png")) icons.add(n); }
        catch(Exception ignored) {}
        Collections.sort(icons); ui();
    }
    private void ui() {
        ScrollView sc=new ScrollView(this);
        LinearLayout root=new LinearLayout(this); root.setOrientation(1); root.setPadding(dp(16),dp(18),dp(16),dp(24)); root.setBackgroundColor(0xff101522); sc.addView(root); setContentView(sc);
        TextView title=txt("Liquid Glass Icon Editor",25,Color.WHITE); title.setTypeface(null,1); root.addView(title);
        root.addView(txt(icons.size()+" иконок · раздельная окраска слоёв",14,0xffbac4da));
        addColorSection(root,"ФОН / МАСКА",true);
        addColorSection(root,"ЛОГОТИП / ПАТТЕРН",false);
        Button reset=new Button(this); reset.setText("СБРОСИТЬ ЦВЕТА");
        reset.setOnClickListener(v->{backgroundColor=Color.rgb(90,55,33);logoColor=Color.rgb(251,184,132);updateLabels();refresh();});
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(48)); rp.topMargin=dp(8); root.addView(reset,rp);
        Button export=new Button(this); export.setText("СОХРАНИТЬ ZIP С ИКОНКАМИ"); export.setOnClickListener(v->exportZip());
        LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(-1,dp(54)); ep.topMargin=dp(12); root.addView(export,ep);
        TextView preview=txt("ПРЕДПРОСМОТР",18,Color.WHITE); preview.setTypeface(null,1);
        LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,-2); pp.topMargin=dp(22); pp.bottomMargin=dp(10); root.addView(preview,pp);
        previewStatus=txt("Все изменения применяются ко всему набору сразу",12,0xffaab6d0);
        root.addView(previewStatus);
        grid=new GridLayout(this); grid.setColumnCount(3); root.addView(grid); refresh();
    }
    private void addColorSection(LinearLayout root,String title,boolean bg) {
        LinearLayout card=new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14),dp(12),dp(14),dp(12));
        card.setBackground(shape(0xff1c2537,18));
        LinearLayout.LayoutParams cardParams=new LinearLayout.LayoutParams(-1,-2);
        cardParams.topMargin=dp(14);
        root.addView(card,cardParams);

        TextView h=txt(title,15,Color.WHITE); h.setTypeface(null,1);
        card.addView(h);
        TextView label=txt("",13,0xffd9e2f5);
        if(bg) bgLabel=label; else logoLabel=label;
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);
        lp.topMargin=dp(5); card.addView(label,lp);

        int[] colors={0xffef5350,0xffff7043,0xffffca28,0xff66bb6a,0xff26a69a,0xff29b6f6,
            0xff5c6bc0,0xffab47bc,0xffec407a,0xffeeeeee,0xff78909c,0xff212121};
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        for(int c:colors) {
            final int chosen=c;
            View sw=new View(this); sw.setBackground(shape(c,30));
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(30),dp(30));
            p.rightMargin=dp(8); row.addView(sw,p);
            sw.setOnClickListener(v->{
                if(bg) backgroundColor=chosen; else logoColor=chosen;
                updateLabels(); refresh();
            });
        }
        HorizontalScrollView scroll=new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false); scroll.addView(row);
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(40));
        sp.topMargin=dp(8); card.addView(scroll,sp);

        Button custom=new Button(this);
        custom.setText("Ввести свой HEX");
        custom.setOnClickListener(v->hexDialog(bg));
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(44));
        bp.topMargin=dp(5); card.addView(custom,bp);
        updateLabels();
    }
    private void updateLabels() {
        if(bgLabel!=null)bgLabel.setText("Цвет фона: "+hex(backgroundColor));
        if(logoLabel!=null)logoLabel.setText("Цвет логотипа/паттерна: "+hex(logoColor));
    }
    private String hex(int c){return String.format(Locale.US,"#%06X",c&0xffffff);}
    private void hexDialog(boolean bg) {
        EditText e=new EditText(this); e.setSingleLine(true); e.setHint("#RRGGBB"); e.setText(hex(bg?backgroundColor:logoColor));
        new AlertDialog.Builder(this).setTitle("Выбери цвет").setView(e).setNegativeButton("Отмена",null).setPositiveButton("Применить",(d,w)->{
            try {String s=e.getText().toString().trim();if(!s.startsWith("#"))s="#"+s;int c=Color.parseColor(s);if(bg)backgroundColor=c;else logoColor=c;updateLabels();refresh();}
            catch(Exception ex){Toast.makeText(this,"HEX неверный. Например #38A6FF",Toast.LENGTH_LONG).show();}
        }).show();
    }
    // The source transform_config.xml defines a two-color grayscale ramp:
    // #5A3721 (dark/background) -> #FBB884 (light/logo and pattern).
    // Project each pixel onto that ramp and interpolate the user's two selected colors.
    // This preserves gradients, glass highlights, shadows, and anti-aliased edges.
    private Bitmap tint(Bitmap src) {
        final int darkR=90, darkG=55, darkB=33;
        final int lightR=251, lightG=184, lightB=132;
        final float vr=lightR-darkR, vg=lightG-darkG, vb=lightB-darkB;
        final float denom=vr*vr+vg*vg+vb*vb;
        int w=src.getWidth(), h=src.getHeight();
        Bitmap out=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
        int[] px=new int[w*h]; src.getPixels(px,0,w,0,0,w,h);
        int br=Color.red(backgroundColor), bg=Color.green(backgroundColor), bb=Color.blue(backgroundColor);
        int lr=Color.red(logoColor), lg=Color.green(logoColor), lb=Color.blue(logoColor);
        for(int i=0;i<px.length;i++) {
            int p=px[i], a=Color.alpha(p);
            if(a==0) continue;
            float pr=Color.red(p)-darkR, pg=Color.green(p)-darkG, pb=Color.blue(p)-darkB;
            float t=(pr*vr+pg*vg+pb*vb)/denom;
            t=Math.max(0f,Math.min(1f,t));
            int r=Math.round(br+(lr-br)*t);
            int g=Math.round(bg+(lg-bg)*t);
            int b=Math.round(bb+(lb-bb)*t);
            px[i]=Color.argb(a,r,g,b);
        }
        out.setPixels(px,0,w,0,0,w,h);
        return out;
    }
    private Bitmap load(String name) {
        try(InputStream in=getAssets().open("icons/"+name)){return BitmapFactory.decodeStream(in);}catch(Exception e){return null;}
    }
    private void refresh() {
        if(grid==null)return;grid.removeAllViews();
        int cell=(getResources().getDisplayMetrics().widthPixels-dp(44))/3;
        for(String n:icons){
            LinearLayout item=new LinearLayout(this);item.setOrientation(1);item.setGravity(Gravity.CENTER);item.setPadding(dp(5),dp(7),dp(5),dp(7));item.setBackground(shape(0xff20283a,14));
            Bitmap b=load(n);if(b!=null){ImageView im=new ImageView(this);im.setImageBitmap(tint(b));im.setScaleType(ImageView.ScaleType.FIT_CENTER);item.addView(im,new LinearLayout.LayoutParams(dp(66),dp(66)));b.recycle();}
            String label=n.replace(".png","");if(label.length()>19)label=label.substring(0,17)+"…";
            TextView t=txt(label,9,0xffe2e8f5);t.setGravity(Gravity.CENTER);t.setMaxLines(2);item.addView(t);
            GridLayout.LayoutParams p=new GridLayout.LayoutParams();p.width=cell;p.height=dp(112);p.setMargins(dp(2),dp(3),dp(2),dp(3));grid.addView(item,p);
        }
    }
    private void exportZip() {
        try {
            File file=new File(getCacheDir(),"LiquidGlass-"+hex(backgroundColor).substring(1)+"-"+hex(logoColor).substring(1)+".zip");
            try(ZipOutputStream z=new ZipOutputStream(new FileOutputStream(file))){
                for(String n:icons){Bitmap b=load(n);if(b==null)continue;Bitmap t=tint(b);ByteArrayOutputStream bytes=new ByteArrayOutputStream();t.compress(Bitmap.CompressFormat.PNG,100,bytes);
                    z.putNextEntry(new ZipEntry("icons/"+n));z.write(bytes.toByteArray());z.closeEntry();b.recycle();t.recycle();}
                z.putNextEntry(new ZipEntry("README.txt"));z.write(("Liquid Glass icons recolored\nBackground: "+hex(backgroundColor)+"\nLogo/pattern: "+hex(logoColor)+"\nIcons: "+icons.size()+"\n").getBytes("UTF-8"));z.closeEntry();
            }
            Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/zip");i.putExtra(Intent.EXTRA_TITLE,file.getName());
            pending=file;
            startActivityForResult(i,77);
        }catch(Exception e){Toast.makeText(this,"Ошибка ZIP: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }
    private File pending;
    @Override protected void onActivityResult(int r,int c,Intent data){
        super.onActivityResult(r,c,data);
        if(r==77&&c==RESULT_OK&&data!=null&&pending!=null){
            try(InputStream in=new FileInputStream(pending);OutputStream out=getContentResolver().openOutputStream(data.getData())){
                if(out==null) throw new IOException("Не удалось открыть файл для записи");
                byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);
                Toast.makeText(this,"ZIP сохранён!",Toast.LENGTH_LONG).show();
            }catch(Exception e){Toast.makeText(this,"Не удалось сохранить ZIP: "+e.getMessage(),Toast.LENGTH_LONG).show();}
        }
    }
}
